with open("contents.txt", 'r', encoding='utf-8') as file:
    poems = file.readlines()  # 读取所有行

    # 创建一个空列表来保存包含"春"字的单独句子
    spring_sentences = []

    # 遍历诗句列表，对每首诗按照句子划分，并检查每一句是否包含"春"字
    for poem in poems:
        sentences = poem.replace('。', '，').split('，')  # 替换和分隔
        for sentence in sentences:
            if "春" in sentence and sentence.strip():
                spring_sentences.append(sentence.strip())  # 添加非空句子

    # 将结果写入新文件
    with open('spring_sentences.txt', 'w', encoding='utf-8') as output_file:
        for spring_sentence in spring_sentences:
            output_file.write(spring_sentence + "\n")

    print("提取完成，结果已保存到 'spring_sentences.txt'。")