# 导包
import requests
from bs4 import BeautifulSoup
import time

for i in range(1, 25):
    url = f"https://www.gushici.net/chaxun/ju/春/{i}"
    print(url)
    time.sleep(1)

    # 设置请求头
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'}
    response = requests.get(url, headers=headers)

    # 获取响应数据
    soup = BeautifulSoup(response.text, 'html.parser')

    # 解析数据
    contents = soup.find_all('a', class_='juzi')

    # 存储数据
    for content in contents:
        print(content.text.strip())
        with open('contents.txt', 'a', encoding='utf-8') as f:
            f.write(content.text.strip())
            f.write("\n")


